app.directive( "academics", function() {
	return {
		templateUrl: 'js/directives/academics.php'
	};
});