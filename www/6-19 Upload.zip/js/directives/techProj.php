<h2>Technical Projects</h2>
<ul>
	<li>Built Personal Profile: http://kyle-oneill.com</li>
	<li>Post open source code in my GitHub: http://github.com/KyletheFox</li>
</ul>