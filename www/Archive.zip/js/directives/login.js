app.directive( "login", function() {
	return {
		templateUrl: 'js/directives/login.php'
	};
});