app.directive('techProj', function() {
	return {
		templateUrl: 'js/directives/techProj.html'
	};
});