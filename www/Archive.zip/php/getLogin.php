<?php 
	// Calls DB to authenticate user
 ?>