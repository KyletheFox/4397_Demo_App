app.directive( "giphy", function() {
	return {
		templateUrl: 'js/directives/giphy.php'
	};
});

$(document).ready(function() {
	
});