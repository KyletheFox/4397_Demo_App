
<h2 class="link-head">Academics</h2>
<img src="img/temple-university-logo.svg">
<ul>
	<li>Temple Universtiy, College of Science and Technology</li>
	<li>Bachelors of Science, Computer Science</li>
	<li>Graduation: December 2016</li>
	<li>GPA: 3.49</li>
</ul>

