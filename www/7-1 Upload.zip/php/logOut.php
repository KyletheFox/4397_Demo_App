<?php 
	$_POST['log_out'] = 1;
 ?>